package com.github.jacksonbrienen.movement_input;

public class KeySet {

	public final int UP, RIGHT, DOWN, LEFT;
	
	public KeySet(int up, int right, int down, int left) {
		UP = up;
		RIGHT = right;
		DOWN = down;
		LEFT = left;
	}
	
}
